```js
<%*
  app.workspace.activeLeaf.rebuildView();
%>
```